//Raj Kamal 2016076
#include<stdio.h>

#include "str.h"

int main(int argc, char *argv[])
{
	char source[ ] = "fresh2refresh" ;
	char target[20]= "" ;
	char src[40];
	char dest[100];
	printf ( "target string after the strcpy( ) = %s\n", my_strncpy(target, source, 5 )  ) ;

	my_memset(dest, '\0', sizeof(dest));
	printf("Final copied string : %s\n", strcpy(dest, strcpy(src, "An example of strcpy")));

	char srcb[50], destb[50];
  printf("Final destination string : |%s|\n",strcat(strcpy(destb, "This is destination"),strcpy(srcb,  "This is source")));

	char srcc[50], destc[50];
	printf("Final destination string : |%s|\n",my_strncat(strcpy(destc, "This is destination"),strcpy(srcc,  "This is source"), 10));

	printf("Strcmp between %s and %s is : %d \n","abcdef","ABCDEF",strcmp("abcdef","ABCDEF"));
	printf("The length of the string %s is : %d \n","abcdef",my_strlen("abcdef"));
	printf("The last occurrence of a character in a string %s is %s \n"," a b c d e f ",strrchr(" a b c d e f ",'d'));
	return 0;
}
