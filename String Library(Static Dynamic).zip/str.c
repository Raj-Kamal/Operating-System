#include <ctype.h>
#include <xlocale.h>				Check Here
#include "str.h"

/* start implementing your functions here */


/* One is done for you */

int my_strncasecmp(const char *s1, const char *s2, int len)
{
	unsigned char c1, c2;

	if (!len)
		return 0;

	do {
		c1 = *s1++;
		c2 = *s2++;
		if (!c1 || !c2)
			break;
		if (c1 == c2)
			continue;
		c1 = tolower(c1);
		c2 = tolower(c2);
		if (c1 != c2)
			break;
	} while (--len);
	return (int)c1 - (int)c2;
}
char *strcpy(char *dest, const char *src)
{
	unsigned i;
  for (i=0; src[i] != '\0'; i++)
    dest[i] = src[i];

  return dest;

}
char *my_strncpy(char *dest, const char *src, int count)

{
    char *ret = dest;
    do {
        if (!count--)
            return ret;
    } while (*dest++ = *src++);
    while (count--)
        *dest++ = 0;
    return ret;
}

char *strcat(char *dest, const char *src){
	int i,j;
	for (i = 0; dest[i] != '\0'; i++)
			;
	for (j = 0; src[j] != '\0'; j++)
			dest[i+j] = src[j];
	dest[i+j] = '\0';
	return dest;
}

	char* my_strncat(char* destination, const char* source, int num)
	{

		char* ptr = destination + strlen(destination);

		while (*source != '\0' && num--)
			*ptr++ = *source++;


		*ptr = '\0';


		return destination;
	}


	int strcmp(const char *s1, const char *s2){
	int i;
     for (i = 0; s1[i] && s2[i]; ++i)
     {
         /* If characters are same or inverting the
            6th bit makes them same */
         if (s1[i] == s2[i] || (s1[i] ^ 32) == s2[i])
            continue;
         else
            break;
     }

     /* Compare the last (or first mismatching in
        case of not same) characters */
     if (s1[i] == s2[i])
         return 0;

     // Set the 6th bit in both, then compare
     if ((s1[i] | 32) < (s2[i] | 32))
         return -1;
     return 1;
	 }


int my_strncmp(const char* s1, const char* s2, int n)
{
    while(n--)
        if(*s1++!=*s2++)
            return *(unsigned char*)(s1 - 1) - *(unsigned char*)(s2 - 1);
    return 0;
}
/*char *strchr(const char *s, int c)
{
    while (*s != (char)c)
        if (!*s++)
            return 0;
    return (char *)s;
}*/

char *strchrnul(const char *s1, int i){
	char *s = strchr(s1, i);

  return s ? s : (char *)s1 + strlen(s1);
}
int strlen(const char *s) {
    int i;
    for (i = 0; s[i] != '\0'; i++) ;
    return i;
}
char *strrchr(const char *s, int c)
{
    char* ret=0;
    do {
        if( *s == (char)c )
            ret=s;
    } while(*s++);
    return ret;
}

char *strnchr(const char *p,  int n,int c)
{
	if (!p)
		return (0);

	while (n-- > 0) {
		if (*p == c)
			return ((char *)p);
		p++;
	}
	return (0);
}
char *skip_spaces(const char *str)
{
    int index, i, j;
    char* ret=str;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            ret[i] = ret[i + index];
            i++;
        }
        ret[i] = '\0'; // Make sure that string is NULL terminated
    }
		return ret;
}
char *strim(char * str)
{
    int index, i;

    /*
     * Trim leading white spaces
     */
    index = 0;
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }

    /* Shift all trailing characters to its left */
    i = 0;
    while(str[i + index] != '\0')
    {
        str[i] = str[i + index];
        i++;
    }
    str[i] = '\0'; // Terminate string with NULL


    /*
     * Trim trailing white spaces
     */
    i = 0;
    index = -1;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index = i;
        }

        i++;
    }

    /* Mark the next character to last non white space character as NULL */
    str[index + 1] = '\0';
		return str;
}


int my_strlen(const char *s) {
    int i;
    for (i = 0; s[i] != '\0'; i++) ;
    return i;
}

int strnlen ( const char *s,int  maxlen)
{
  register const char *e;
  int n;

  for (e = s, n = 0; *e && n < maxlen; e++, n++)
    ;
  return n;
}
void *my_memset(void *s, int c, int n)
{
    unsigned char* p=s;
    while(n--)
        *p++ = (unsigned char)c;
    return s;
}
