#include <ctype.h>
#include <xlocale.h>
#include "str.h"

/* start implementing your functions here */


/* One is done for you */


void check(char a[]){
	int i;
	for(i=0; i<my_strlen(a); i++){
			if(a[i]=='\n'){
					a[i]='\0';
			}
	}
}
int my_strlen(char s[]) {
    int i;
    for (i = 0; s[i] != '\0'; i++) ;
    return i;
}
char *my_strcat(char *dest,char *src){
	int i,j;
	for (i = 0; dest[i] != '\0'; i++)
			;
	for (j = 0; src[j] != '\0'; j++)
			dest[i+j] = src[j];
	dest[i+j] = '\0';
	return dest;
}
