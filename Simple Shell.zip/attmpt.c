#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max_input 1024
int main() {
  char line[max_input];
  char* cmd[150];
  char* path= "/bin/";
  char addr[50];
while(1){
    printf("New Shell>> ");
    if(!fgets(line,max_input,stdin))
    {
      break;
    }
      int length = my_strlen(line);
      if (line[length - 1] == '\n'){
        line[length - 1] = '\0';}
        if(strcmp(line, "exit")==0)
        {
                  break;
        }
    char *pointr;
    pointr = strtok(line," ");
    int i=0;
  	while(pointr!=NULL){
  		cmd[i]=pointr;
  		pointr= strtok(NULL," ");
  		i++;
  	}
  	cmd[i]=NULL;
    strcpy(addr, path);
    my_strcat(addr, cmd[0]);
    check(addr);
    int pid= fork();
    if(pid==0){
      execvp(addr,cmd);
      fprintf(stderr, "Command not recognised {CHILD} Process\n");
    }
    else{
      wait(NULL);
      printf(" {PARENT} Process\n");

    }
}
}
