/**
 * my_strncasecmp - Case insensitive, length-limited string comparison
 * @s1: One string
 * @s2: The other string
 * @len: the maximum number of characters to compare
 */

void check(char a[]);
int my_strlen(char s[]);
char *my_strcat(char *dest,char *src);
